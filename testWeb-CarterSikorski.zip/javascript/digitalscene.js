function setup() {
	var canvas=createCanvas(500, 500);
	background(102,178,255);
	
}
function draw() {
	fill(0,153,0);
	rect(0,400,500,100);
	fill(255,255,0);
	ellipse(50,50,65,65);
	fill(224,224,224);
	rect(100,250,200,150);
	fill(224,224,224);
	rect(125,190,40,50);
	fill(255,0,0);
	triangle(75, 250, 200, 200, 325, 250);
	fill(0,0,0);
	rect(125,260,40,40);
	fill(0,0,0);
	rect(235,260,40,40);
	fill(102,51,0);
	rect(182,350, 35, 50,);
	textSize(18);
	fill(0,0,0);
	text("ACSCompSciPandemic2020 Carter S", 25,150);
}
