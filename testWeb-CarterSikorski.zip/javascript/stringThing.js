function setup() {
  var canvas=createCanvas(500,500);
	background(0,0,0);
}

function draw() {
	textSize(48);
	textAlign(CENTER);
	fill(255,255,255);
	text("ACS: 2020", 175,125);
	
	textSize(32);
	textAlign(RIGHT);
	fill(160,160,160);
	text("Carter Sikorski", 225,175);
	
	textSize(24);
	textAlign(LEFT);
	fill(102,102,102);
	text("Period 1", 175,210);

}